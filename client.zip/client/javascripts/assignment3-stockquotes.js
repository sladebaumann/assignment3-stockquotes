(function () {
    window.app={

        settings: {
            refresh: 1000,
            ajaxUrl: "http://server7.tezzt.nl/~theotheu/stockquotes/index.php"
        },

        series:{},

        rnd: function(min, max) {
            // return a value between min and max,
            // eg. if the current value is 100,
            // then the new value will be a float between
            // 100-min, 100+max
            return (Math.floor(
                (
                Math.random() * (max - min) + min)
            )
            );
        },

        getFormattedDate: function(d) {
            // Return a formatted date string that looks like
            // month/day/year
            // year is 4 digits
        },

        getFormattedTime: function(d) {
            // am, pm
        },

        generateTestData: function() {
            var company, quote, newQuote;

            for(company in app.series) {
                quote = app.series[company][0];
                newQuote=Object.create(quote);
                newQuote.col1=123; // new value
                newQuote.col2=new Date(); // new dage
                newQuote.col3=new Date(); // new time
                newQuote.col4=0; // difference of price value between this one and the previous quote

                app.series[company].push(newQuote);

            }
        },

        parseData: function(rows){
            var i, company;

            //iterate over the rows and add to the series
            for(i=0; i<rows.length; i++) {
                company = rows[i].col0;

                //check if array for company exists
                if (app.series[company] !== undefined) {
                    app.series[company].push(rows[i]);
                } else {
                    //company does not yet exist
                    app.series[company] = [rows[i]];
                }
            }
        },

        retrieveData: function(){

        },

        createValidCSSNameFromCompany: function(str){
            //regular expression to remove everything
            //that is not out of A-z0-9
            return str.replace(/\W/, "");
        },


        showData: function(){
            //return value is a dom
            var company, table, row, quote, cell, propertyName, propertyValue, tableHeader, headerArray;


            //create table
            table = document.createElement("table");

            //create header
            //created myself
            row = document.createElement("tr");

            for (var i = 0;i<9;i++){
                tableHeader = document.createElement("th");
                if (i===0){
                    tableHeader.innerText = 'Company';
                }else if (i===1){
                    tableHeader.innerText = 'Idk';
                }else if (i===2){
                    tableHeader.innerText = 'Date';
                }else if (i===3){
                    tableHeader.innerText = 'Time';
                }else if (i===4){
                    tableHeader.innerText = 'Time';
                }else if (i===5){
                    tableHeader.innerText = 'Time';
                }else if (i===6){
                    tableHeader.innerText = 'Time';
                }else if (i===7){
                    tableHeader.innerText = 'Time';
                }else if (i===8){
                    tableHeader.innerText = 'Time';
                }

                row.appendChild(tableHeader);
            }
            table.appendChild(row);

            //create rows
            for (company in app.series){
                quote=app.series[company][0];
                row = document.createElement("tr");
                row.id=app.createValidCSSNameFromCompany(company);

                //create cells
                table.appendChild(row);

                //iterate over quote to create cells
                for(propertyName in quote) {
                    propertyValue = quote[propertyName];
                    cell = document.createElement("td");
                    cell.innerText=propertyValue;
                    row.appendChild(cell);
                }
                //adds class names to rows, so that it can be styled accordingly
                if(quote.col4<0){
                    row.className='loser';
                } else if (quote.col4 > 0){
                    row.className = 'winner';
                } else if (quote.col4 === 0){
                    row.className = 'neutral';
                }
            }

            return table;
        },

        //TODO: add data from AJAX request
        getDataFromAJAX: function() {
            var xhr;
            xhr = new XMLHttpRequest();
            xhr.open("GET",app.settings.ajaxUrl);
            xhr.addEventListener('load',app.retrieveJSON());
            xhr.send();
        },

        //TODO: add method to parse JSON
        //TODO: add checks
        retrieveJSON: function(e) {
            app.parseData(JSON.parse(e.target.responseText));
        },

        loop: function(){
            var table;

            //generateFakeData();
            app.parseData(data.query.results.row);
            app.generateTestData();


            //remove old table
            //if table exists, then run this
            if (document.querySelector("table")){
                document.querySelector("#container").removeChild(document.querySelector("table"));
            }

            //add new table
            if (!(document.querySelector("table"))){
                table = app.showData();
                app.container.appendChild(table);
            };


            //set time out so that it refreshes
            window.setTimeout(app.loop,app.settings.refresh);

        },

        initHTML: function(){
            var container;

            container=document.createElement("div");
            container.id="container";

            app.container = container;

            h1Node = document.createElement("h1");
            h1Node.innerText="Real Time Stockquote App";

            app.container.appendChild(h1Node);

            document.querySelector("body").appendChild(app.container);

            return app.container;
        },

        init: function(){
            var domNodes;
            domNodes = app.initHTML();
            document.body.appendChild(domNodes);
            app.loop();
        }
    }
}());