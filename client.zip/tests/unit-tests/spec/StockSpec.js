/*jslint browser: true, plusplus:true*/

//stock test for reference
describe("warming up", function () {

    //you can't test anything that returns "undefined"

    //need at least one test for each property and method
    //more tests are better

    //every method should do one thing

    //have to test for the DOM as well

    it("assertion", function () {
        expect(1).toBe(1);
    });

    it("Should succeed", function() {
        expect(1).toBe(1);
    });

    it("Should fail", function() {
        expect(1).toBe(1);
    });

    /*it ("Should verify empty stockquotes.stock", function(){
        expect(app.container.length).toBe(0);
    });

    it ("Should verify a valid result from init", function() {
        expect(app.init()).toBe(undefined);
    });*/

});

describe("HTML tests", function() {

    beforeEach(function () {
        app.init();
    });

    it("Should verify a valid result from init", function(){
        expect(app.init()).toBe(undefined);
    });
    it("should create DOM elements for container and page title", function(){
        var expectedValue = "Real Time Stockquote App";
        var actualValue = app.initHTML().querySelector("h1").innerText;
        expect(actualValue).toBe(expectedValue);
    });

    it("Should verify that only letters and numbers remian:", function() {
        var actualValue = app.createValidCSSNameFromCompany("HGF>&^");
        var expectedValue = "HGF";
        expect(actualValue).toBe(expectedValue);
    });

    it("Should verify that the table has 25 rows", function(){
        var expectedValue, actualValue;

        expectedValue=25;
        actualValue=app.showData().querySelector();

        expect(actualValue).toBe(expectedValue);
    });
});