Static anylyzer for syntax check
--------------------------------

Requirements

* [Node.js](http;//nodejs.org)
* npm packages, run `npm install` from this directory.

`./run_lint.sh` and check the results in `./error_log.txt`